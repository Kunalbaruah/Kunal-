/**
 * Portfolio JavaScript
 * Handles: Loader, Typing Animation, Navbar Scroll, Mobile Menu,
 *          Scroll Reveal, Active Nav, Back to Top, Stat Counter,
 *          Skill Bar Animations, Tilt Effect
 */

document.addEventListener('DOMContentLoaded', () => {

    // =========================================================
    // 1. LOADING ANIMATION
    // =========================================================
    const loader = document.getElementById('loader');

    window.addEventListener('load', () => {
        setTimeout(() => {
            loader.classList.add('hidden');
            document.body.classList.remove('loading');
            // Trigger initial reveals after loader disappears
            setTimeout(() => {
                revealElements();
                animateSkillBars();
                animateCounters();
            }, 400);
        }, 800);
    });

    // =========================================================
    // 2. TYPING ANIMATION
    // =========================================================
    const typingElement = document.querySelector('.typing-text');
    if (typingElement) {
        const texts = JSON.parse(typingElement.getAttribute('data-texts'));
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        let typeDelay = 120;

        function type() {
            const currentText = texts[textIndex];

            if (isDeleting) {
                typingElement.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
                typeDelay = 50;
            } else {
                typingElement.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
                typeDelay = 120;
            }

            if (!isDeleting && charIndex === currentText.length) {
                isDeleting = true;
                typeDelay = 2200; // Pause at full text
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
                typeDelay = 400; // Pause before next word
            }

            setTimeout(type, typeDelay);
        }

        // Start typing after a small delay
        setTimeout(type, 1200);
    }

    // =========================================================
    // 3. NAVBAR SCROLL EFFECT
    // =========================================================
    const navbar = document.getElementById('navbar');

    function handleNavbarScroll() {
        if (window.scrollY > 40) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }

    window.addEventListener('scroll', handleNavbarScroll, { passive: true });
    handleNavbarScroll(); // Run once on load

    // =========================================================
    // 4. MOBILE MENU
    // =========================================================
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('nav-links');
    const navItems = document.querySelectorAll('.nav-links li a');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            const isOpen = hamburger.classList.toggle('active');
            navLinks.classList.toggle('active');
            hamburger.setAttribute('aria-expanded', isOpen);
        });

        // Close menu when a nav item is clicked
        navItems.forEach(item => {
            item.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navLinks.classList.remove('active');
                hamburger.setAttribute('aria-expanded', 'false');
            });
        });

        // Close menu on outside click
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
                hamburger.classList.remove('active');
                navLinks.classList.remove('active');
                hamburger.setAttribute('aria-expanded', 'false');
            }
        });
    }

    // =========================================================
    // 5. SCROLL REVEAL ANIMATION
    // =========================================================
    function revealElements() {
        const reveals = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');

        reveals.forEach(element => {
            const windowHeight = window.innerHeight;
            const elementTop = element.getBoundingClientRect().top;
            const revealPoint = 120;

            if (elementTop < windowHeight - revealPoint) {
                element.classList.add('active');
            }
        });
    }

    window.addEventListener('scroll', revealElements, { passive: true });

    // =========================================================
    // 6. ACTIVE NAV LINK ON SCROLL
    // =========================================================
    const sections = document.querySelectorAll('section[id]');

    function updateActiveNav() {
        const scrollY = window.scrollY + 120;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            const sectionId = section.getAttribute('id');

            if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
                navItems.forEach(a => {
                    a.classList.remove('active');
                    if (a.getAttribute('href') === '#' + sectionId) {
                        a.classList.add('active');
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', updateActiveNav, { passive: true });

    // =========================================================
    // 7. BACK TO TOP BUTTON
    // =========================================================
    const backToTopBtn = document.getElementById('back-to-top');

    function toggleBackToTop() {
        if (window.scrollY > 500) {
            backToTopBtn.classList.add('show');
        } else {
            backToTopBtn.classList.remove('show');
        }
    }

    window.addEventListener('scroll', toggleBackToTop, { passive: true });

    // =========================================================
    // 8. ANIMATED NUMBER COUNTERS
    // =========================================================
    function animateCounters() {
        const counters = document.querySelectorAll('.stat-number[data-count]');

        counters.forEach(counter => {
            if (counter.dataset.animated) return;

            const target = parseInt(counter.getAttribute('data-count'));
            const duration = 1500;
            const step = Math.ceil(duration / target);

            let current = 0;

            const updateCounter = () => {
                if (current < target) {
                    current++;
                    counter.textContent = current;
                    setTimeout(updateCounter, step);
                } else {
                    counter.textContent = target;
                    counter.dataset.animated = 'true';
                }
            };

            // Only start if element is in viewport
            const rect = counter.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                updateCounter();
            }
        });
    }

    window.addEventListener('scroll', animateCounters, { passive: true });

    // =========================================================
    // 9. SKILL BAR ANIMATION
    // =========================================================
    function animateSkillBars() {
        const skillCards = document.querySelectorAll('.skill-card');

        skillCards.forEach(card => {
            const rect = card.getBoundingClientRect();
            if (rect.top < window.innerHeight - 80 && !card.classList.contains('animated')) {
                card.classList.add('animated');
            }
        });
    }

    window.addEventListener('scroll', animateSkillBars, { passive: true });

    // =========================================================
    // 10. TILT EFFECT ON SKILL CARDS (Desktop only)
    // =========================================================
    if (window.matchMedia('(hover: hover)').matches) {
        const tiltCards = document.querySelectorAll('[data-tilt]');

        tiltCards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateX = ((y - centerY) / centerY) * 6;
                const rotateY = ((centerX - x) / centerX) * 6;

                card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-6px)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });
    }

    // =========================================================
    // 11. SMOOTH SCROLL FOR ANCHOR LINKS
    // =========================================================
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                const offsetTop = targetElement.offsetTop - (navbar ? navbar.offsetHeight : 0);

                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });

});
